﻿#Име Matching Brackets
#Условие
We are given an arithmetic expression with brackets. Scan through the string and extract each sub-expression.
Print the result back at the terminal.