﻿#Име Stack Sum
#Условие
Create a program that:
Reads an input of integer numbers and adds them to a stack.
Reads and executes commands until "end" is received.
Process the following commands:
 Add <n1> <n2>: pushes two numbers into the stack
 Remove <n>: removes the n elements from the stack or does nothing if the stack holds less than n elements.
Prints the sum of the remaining elements of the stack.