﻿#Име Simple Calculator
#Условие
Create a simple calculator that can evaluate simple expressions with only addition and subtraction. There will not
be any parentheses. Numbers and operations are space-separated.
Solve the problem using a Stack.