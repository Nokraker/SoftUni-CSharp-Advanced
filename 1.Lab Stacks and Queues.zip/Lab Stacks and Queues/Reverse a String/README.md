﻿#Име Reverse a String
#Условие на задачата
Create a program that: 
Reads an input string
Reverses it backwards (letter by latter, from the last to the first) using a Stack<T>
Prints the result back at the console